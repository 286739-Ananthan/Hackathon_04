from django.shortcuts import render
import random

def salary_form(request):
    return render(request, 'form.html')

def salary_result(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        gross_salary = float(request.POST.get('gross_salary', 0))
        tax = float(request.POST.get('tax', 0))
        bonus = float(request.POST.get('bonus', 0))

        net_salary = gross_salary - (gross_salary * tax / 100) + (gross_salary * bonus / 100)

        return render(request, 'result.html', {
            'name': name,
            'net_salary': round(net_salary, 2)
        })

    return render(request, 'form.html')

def jumble_word(request):
    jumbled = ''
    if request.method == 'POST':
        word = request.POST.get('word', '')
        word_list = list(word)
        random.shuffle(word_list)
        jumbled = ''.join(word_list)

    return render(request, 'jumble.html', {'jumbled': jumbled})
